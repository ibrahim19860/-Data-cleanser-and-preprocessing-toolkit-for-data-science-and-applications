import pandas as pd
import data_cleaning_toolkit as dct

def main():
    data = {
        'Age': [25, 22, None, 28, 35, 29, None, 40],
        'Salary': [50000, 48000, 51000, None, 55000, None, 52000, 56],
        'Height': [5.5, 5.42, 5.75, 5.58, None, 5.92, 5.4, 5.8],
        'Gender': ['Male','Female','Female', 'Male', 'Male', 'Male', 'Female', 'Male']
    }
    df = pd.DataFrame(data)
    print("Original DataFrame:")
    print(df)

    df = dct.fill_missing_with_mean(df, 'Age')
    df = dct.fill_missing_with_mean(df, 'Salary')
    df = dct.fill_missing_with_median(df, 'Height')

    df = dct.remove_outliers_iqr(df, 'Salary')
    df = dct.z_score_outliers(df, 'Height')

    # df = dct.min_max_scaling(df, 'Age')
    df = dct.encode_categorical_one_hot(df, 'Gender')
    # df = dct.encode_categorical_label(df, 'Gender')

    print("\nCleaned DataFrame:")
    print(df)

if __name__ == "__main__":
    main()
